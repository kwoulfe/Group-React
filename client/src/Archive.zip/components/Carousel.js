import React from "react";

const Carousel = () => (


    < div class="jumbotron text-center" >

        <div className="jumbotron">
            <h1 class="h1-reponsive mb-3 font"><strong>

            </strong></h1>
            <p class="lead font2">Explore new and developing apps!</p>

        </div>
    </div >
);

export default Carousel;
