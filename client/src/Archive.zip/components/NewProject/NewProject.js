import React from 'react';

function NewProject(props) {
    return (
        <div>
            <a className="nav-link">Start a Project</a>
        </div>
    )
}

export default NewProject;
